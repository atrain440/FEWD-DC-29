#Layouts with Bootstrap

Now that you have your feet wet a bit with Bootstrap, let's start putting it to use. Check out the .pdf in this folder - we're going to lay a couple of these out using the Bootstrap grid system. If you are getting ambitious, try putting a navbar on there.

We'll build the first two of these together, then it's up to you and a partner to get the rest of them done.
