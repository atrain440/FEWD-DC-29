$(document).ready(function() {
    // Instantiate the carousel.
    $('.carousel').carousel();
});
