$(document).ready(function() {

    // Form validation goes here!

});